csvSplitter (Comma Separated Values File Splitter that Generates Statistics and Charts)
v0.3.1.1
Version Release: 2022/02/01


Description: 
	csvSplitter can split a csv file created from Microsoft's Perfmon* into spreadsheet files (reports) based on specific, built-in Counter Names.
	Each spreadsheet report contains a statistical breakdown of the values for its repsective counter as well as an automatically generated chart based 
	on the raw values.
	The goal of this utility is to speed up the time to perform post-processing and analysis on a Perfmon performance collection.

	* For an overview of Microsoft Perfmon, please see: 
		https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2008-R2-and-2008/cc749154(v%3dws.11)
		https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2008-R2-and-2008/cc749115%28v%3dws.10%29


Requirements:
  csvSplitter expects the input csv file to contain at least one of the following MS Perfmon counters (for one or more machines):
	"% Processor Time"
	"Available MBytes"
	"Available KBytes"
	"Available Bytes"
	"Committed Bytes"
	"% Committed Bytes In Use"
	"% Idle Time"
	"Disk Read Bytes/sec"
	"Disk Write Bytes/sec"
	"Bytes Sent/sec"
	"Bytes Received/sec"
	"Process*"
  These names are considered "built-in counters" (e.g. built-in Counter Names)


How to use:
	Typical use: 
		csvSplitter.CLI.exe -c "Path_to_CSV_file.csv" -o "C:\some_path\some_output_folder\" -r xlsx

	Specialized uses...
		Limit maximum number of lines:
			csvSplitter.CLI.exe -c "Path_to_CSV_file.csv" -o "C:\some_path\some_output_folder\" -r xlsx -m max_number_of_lines_to_use
		Invert CPU chart (dstat Linux csv sources):
			csvSplitter.CLI.exe -c "Path_to_CSV_file.csv" -o "C:\some_path\some_output_folder\" -r xlsx -i true


Example:
	csvSplitter.CLI.exe -c C:\Users\username\Documents\CSV\PerformanceCSVSample01.csv -o "C:\Users\username\Documents\CSV" -r xlsx
	or
	csvSplitter.GUI.exe


-------------------------------
* CHANGELOG

Build 0.3.1.1 (Prerelease)
--------------
1. Removed some unneeded files included with the package

Build 0.3.1.0b (Prerelease)
--------------
1. Both csvSplitter.GUI.exe and csvSplitter.CLI.exe are now 64bit

Build 0.3.0.1b (Prerelease)
--------------
1. Increased the size of the alphabetical string array from 125 to 10,000. 
   This array is used for report formatting. The larger array size enables csvSplitter to read in files with more than 125 columns of data.

Build 0.3.0.0b (Prerelease)
--------------
1. Added a GUI called csvSplitter.GUI.exe to csvSplitter; either the GUI or CLI can be run to generate reports

Build 0.2.4.2b (Prerelease)
--------------
1. Greatly improved performance and memory consumption over last release for working with large csv files
2. Added some print statements to keep methods to better see the report creation progress when working with large csv files

Build 0.2.4.1b (Prerelease)
--------------
1. Fixed command line help listing that displayed the "-i" argument as "-t"
2. Fixed an issue where the chart data would not display if all the values were under 100
3. Fixed a display issue where the column data values would display at full size
4. Corrected an issue with the display of the tool version information inside the created spreadsheet report files

Build 0.2.4.0b (Prerelease)
--------------
1. Show Help when "-h" is passed as a command line argument
2. Added support to create report files if "Available KBytes", "Available Bytes", "Committed Bytes" or "% Committed Bytes In Use" data columns were present. This support was missing with earlier versions.
3. Added the "-i" boolean command line argument option to invert the CPU chart values. This is helpful if the CPU values originated from a source such as dstat for Linux.

Build 0.2.3.0b (Prerelease)
--------------
1. Added feature to detect the presence of only one data column which then automatically sets the excel chart to only render in one color

Build 0.2.2.1b (Prerelease)
--------------
1. Corrected the command-line help to include information on the optional switches that can be passed into csvSplitter

Build 0.2.2.0b (Prerelease)
--------------
1. Added a check on the existence of the input file 
2. Avoid printing xlsx reports on files that dont exist
3. Corrected the reported exe architecture in xlsx reports
4. Switched default reporttype to be xlsx
5. Changeed the check on timefield column from "(PDH-CSV 4.0) (Coordinated Universal Time)(0)" to a wild card search for just "(PDH-CSV 4.0)"
6. Properly filter on "Process % Processor Time"
7. Auto adjust the maximum chart Y-Axis value for the largest "Process % Processor Time" value
8. Added print verbosity for each xlsx report created
9. csvSplitter now includes some sample csv files

Build 0.2.1.0b (Prerelease)
--------------
1. Fixed issue where csvSplitter could not read file due to each field containing double-quotes 
2. Removed unused code
3. Minor code reorganization
4. Fixed issue where csvSplitter now creates reports for all built-in counters. This currently creates reports, even if the counters do not exist in the input csv file.

Build 0.2.0.0b (Prerelease)
--------------
1. Added support for command line switches
2. Added support to create a csv or xlsx file
3. Added statistics support for easier digestion of values
4. Added automatic chart generation

Build 0.1.1.0b (Prerelease)
--------------
1. Added some checks to detect if the output files are in use and kindly warn the user
2. Added an additional "time column" called "SampleInterval" for quickly creating charts. "SampleInterval" is the duration of time between each sample capture (e.g. 10 seconds, 15 seconds) and make a handy X-axis.

Build 0.1.0.0b (Prerelease)
--------------
Initial Build